Author-preprint revision prepared locally; not uploaded.
Build: latexmk -pdf main.tex
Alternative: tectonic --untrusted main.tex
Generated audit_numbers.tex and all referenced figures are included.
Audit: https://github.com/integrallis/self-grading-gap
